CADDY 1.0.4

Website
	https://caddyserver.com

Community Forum
	https://caddy.community

Twitter
	@caddyserver

Source Code
	https://github.com/caddyserver/caddy
	https://github.com/caddyserver


For instructions on using Caddy, please see the docs on the
website. For a list of what's new in this version, see
CHANGES.txt.

For a good time, follow @mholt6 on Twitter.

Want to get involved with Caddy's development? We love to have
contributions! Please file an issue on GitHub to discuss a
change or fix you'd like to make, then submit a pull request
and we'll review it! Your contributions will reach millions
of people who connect to sites served by Caddy.

Extend Caddy by developing a plugin for it! Instructions on
the project wiki: https://github.com/caddyserver/caddy/wiki

And thanks - you're awesome!


---
(c) 2015-2019 Light Code Labs, LLC
